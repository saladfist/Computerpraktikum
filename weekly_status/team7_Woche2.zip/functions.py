#! ./venv/bin/python3
#%%
import matplotlib.pyplot as plt
import pandas as pd
from collections import deque, defaultdict

def get_coordinate(data,idx,dim):
    return data[idx][dim]

def precompute_cubes(data,cube_length,dimension):
    cubes_dict=defaultdict(list) #dictionary to hold the cubes belonging to data points and their counts 
    for idx,point in enumerate(data):
        cube_idx=tuple([int((get_coordinate(data,idx,d)+1)/(2*cube_length)) for d in range(dimension)])
        cubes_dict[cube_idx].append(idx)
    return cubes_dict

def compute_h_values(data, delta, cubes_dict):
    """Compute h_D_delta for all data points."""
    n = len(data)
    d = len(data[0])
    
    h_values = [0]*n
    
    for cube_idx, point_indices in cubes_dict.items():
        count = len(point_indices)
        h_cube = count / (n * (2 * delta) ** d)
        
        for idx in point_indices:
            h_values[idx] = h_cube
    
    return h_values
def h_D_delta(x, data, delta, precomputed_cubes=None):
    n=len(data)
    d=len(data[0])    
    if precomputed_cubes is None:
        precomputed_cubes=precompute_cubes(data, delta,d)
    # Get the cube index for x
    x_cube = tuple([int(((x_d)+1)/(2*delta)) for x_d in x])
    # Only count data points in the same cube as x
    h=precomputed_cubes.get(x_cube, 0)
    
    h=h/(n*(2*delta)**d)
    return h

def get_distance_sq(data,p1,p2,dimension):
    dist_2=0
    for d in range(dimension):
        dist_2+=(get_coordinate(data,p1,d)-get_coordinate(data,p2,d))**2
    return dist_2
# iteration over thresholds and find M intervals
def get_cubes_in_M_rho(cubes_dict, rho, h_values):
    """Get cubes that are part of M_rho """
    cubes_in_M = {}
    
    for cube_idx, point_indices in cubes_dict.items():
        # Check if any point in this cube has h >= rho
        for idx in point_indices:
            if h_values[idx] >= rho:
                cubes_in_M[cube_idx] = point_indices
                break
    return cubes_in_M

def optimized_tau_connected_clusters(data,M,tau,dimension):
    """
    M list
    tau float
    """
    tau_sq=tau**2

    cube_idx_to_point=defaultdict(list)
    point_to_cube_index = {}
    
    def get_cube_idx(point):
        #finds the cube a particular point belongs to 
        return tuple([int((get_coordinate(data,point,d)+1)/(2*tau)) for d in range(dimension)])
    
    def get_cube_neighbors(dimension):
        #returns a list of lists with every distance a cube has to its neighbors in d dimensions
        offsets=[[]]
        for d in range(dimension):
            offsets=[o+[i] for o in offsets for i in [-1,0,1]]
        return [tuple(o) for o in offsets]
    
    for point in M:
        c_idx=get_cube_idx(point)
        cube_idx_to_point[c_idx].append(point) #defaultdict means that if key (c_idx) doesnt exist we create it with corresponding empty list to which we append our values
        point_to_cube_index[point]=c_idx

    offsets=get_cube_neighbors(dimension)
    visited=[False]*len(data)
    clusters=[]
    for start_point in M:
        if visited[start_point]:
            continue #ensures we only start newq clusters from unvisited points

        point_stack=[start_point] #again we can use actual stack maybe
        current_cluster=set([start_point])
        while point_stack:
            p=point_stack.pop() #remove current point from stack
            visited[p]=True
            pc=point_to_cube_index[p]
            px=data[p]
            for offset in offsets:
                nghbr_cube=tuple(pc[d]+offset[d] for d in range(dimension))
                if nghbr_cube not in cube_idx_to_point: #skips if cube contains no points
                    continue
                
                for q in cube_idx_to_point[nghbr_cube]:
                    if visited[q]:
                        continue
                    qx=data[q]
                    dist_sq=0.0
                    for d in range(dimension):
                        dist_sq+=(px[d]-qx[d])**2
                        if dist_sq>tau_sq:
                            break
                    if  dist_sq<=tau_sq :
                        visited[q]=True
                        point_stack.append(q)
                        current_cluster.add(q)
                        
        clusters.append(current_cluster)
    return clusters

def small_cube_clustering(data, M, tau, dimension):

    tau_sq = tau**2
    cell_size = tau / (2*2**((dimension-1)/2)) # with these cubes it is guaranteed that all point within one cell and its neighboring cells are connected
    
    # Build grid with tau/sqrt(d) sized cells
    cube_idx_to_point = defaultdict(set)
    point_to_cube_index = {}
    
    def get_cube_idx(point_idx):
        point = data[point_idx]
        return tuple(int(point[d] / cell_size) for d in range(dimension))
    
    def get_cube_neighbors(dimension):
        # points within tau could be in cells up to int(d**0.5+1) away
        max_offset = int(2*2**((dimension-1)/2)) + 1
        #returns a list of lists with every distance a cube has to its neighbors in d dimensions
        offsets=[[]]
        for d in range(dimension):
            offsets=[o+[i] for o in offsets for i in range(-max_offset, max_offset + 1)]
        return [tuple(o) for o in offsets]
    
    # Generate all offsets within this range
    offsets=get_cube_neighbors(dimension)
    for point in M:
        c_idx=get_cube_idx(point)
        cube_idx_to_point[c_idx].add(point) #defaultdict means that if key (c_idx) doesnt exist we create it with corresponding empty list to which we append our values
        point_to_cube_index[point]=c_idx
    
    cube_graph = defaultdict(set)
    
    cube_to_rep = {} #dictionary mapping cube to one representative point in cube
    for cell, points in cube_idx_to_point.items():
        if points:
            cube_to_rep[cell] = next(iter(points)) #gets arbitraty element from cell from first entry of iterator
    
    for c1, rep1 in cube_to_rep.items():
        x1 = data[rep1]
        
        for offset in offsets:
            c2 = tuple(c1[d] + offset[d] for d in range(dimension))
            
            if c2 not in cube_to_rep or c1 == c2: #skip if same cube or no pints in cube
                continue
            
            if c2 in cube_graph[c1]: #if already connected
                continue
            
            # Check distance between representatives
            rep2 = cube_to_rep[c2]
            x2 = data[rep2]
            
            dist_sq = 0.0
            for d in range(dimension):
                diff = x1[d] - x2[d]
                dist_sq += diff * diff
                if dist_sq > tau_sq:
                    break
            
            if dist_sq <= tau_sq:
                # Cells are connected
                cube_graph[c1].add(c2)
                cube_graph[c2].add(c1)
    
    # Merge connected cubes
    visited_cubes = set()
    clusters = []
    
    for cube in cube_to_rep:
        if cube in visited_cubes:
            continue
        
        # Find all connected cells
        component_cubes = set()
        stack = [cube]
        visited_cubes.add(cube)
        
        while stack:
            current = stack.pop()
            component_cubes.add(current)
            
            for neighbor in cube_graph[current]:
                if neighbor not in visited_cubes:
                    visited_cubes.add(neighbor)
                    stack.append(neighbor)
        
        # Merge all points from these cubes
        cluster = set()
        for cell in component_cubes:
            cluster.update(cube_idx_to_point[cell])
        
        if cluster:
            clusters.append(cluster)
    
    return clusters

def drop_clusters(B,h_values,rho,epsilon): #drop B if it contains no h with h geq ρ + 2ε
    remaining_clusters=[]
    for cluster in B:
        max_h=max([h_values[i] for i in cluster])
        if max_h>=rho+2*epsilon:
            remaining_clusters.append(cluster)
    return remaining_clusters

def iteration_over_rho(data,delta,epsilon_factor,tau_factor):
    n=len(data)
    d=len(data[0])
    h_values=[]
    
    cubes_dict = precompute_cubes(data, delta, d)
    for x in data:
        h = h_D_delta(x, data, delta, precomputed_cubes=cubes_dict)
        h_values.append(h)
    h_max = max(h_values)
    
    epsilon=epsilon_factor*(h_max/(n*(2*delta)**d))**.5
    tau=tau_factor*delta
    rho_step=1/(n*(2*delta)**d)

    rho_history=[]
    B_history=[]
    # find equivalence classes and clusters
    rho=0
    M_cubes=get_cubes_in_M_rho(cubes_dict,rho,h_values)
    B_current=small_cube_clustering(data,M_cubes,tau,d)
    
    while True:
        remaining_clusters=drop_clusters(B_current,h_values,rho,epsilon)
        
        if len(remaining_clusters)!=1: #or (M_initial==1 and multiple_clusters): # I think if there exist only 1 cluster B and we dont stop the recursion, then we just increase rho until no clusters remain which leads to large gaps in the clusters, might have to think through
            break
        
        rho_history.append(rho)
        B_history.append(B_current)
        rho+=rho_step
        #update M and B for next iteration
        M_next=get_M(data,rho,h_values)
        B_current=small_cube_clustering(data,M_next,tau,d)
    return B_current, rho_history,B_history
    

    
def save_clusters(data,clusters,dimension,dataset_name):
    output=[]
    for cluster_id,cluster in enumerate(clusters):
        for point in cluster:
            output.append({"cluster":cluster_id,"idx":point,"coordinate":[get_coordinate(data,point,d) for d in range(dimension)]})
    df=pd.DataFrame(output)
    df[[f"coordinate_{i}" for i in range(dimension)]]=pd.DataFrame(df.coordinate.tolist(),index=df.index)
    df.assign(freq=df.groupby('cluster')['cluster'].transform('count'))\
  .sort_values(by=['freq','cluster'],ascending=[False,True])
    df[["cluster"]+[f"coordinate_{i}" for i in range(dimension)]].to_csv(f"cluster-results/team-7-{dataset_name}.result.csv",index=False,header=False)
        
def save_log(rho_history,B_history,dataset_name):
    output=[]
    for i,rho in enumerate(rho_history):
        d={"rho":rho}
        for j,cluster in enumerate(B_history[i]):
            d[f"B{j}"]=int(len(cluster))
        output.append(d)
    df=pd.DataFrame(output)  
    df.to_csv(f"cluster-results/team-7-{dataset_name}.log",index=False,header=False)

def plot_clusters(data,clusters,dimension,dataset_name):
    if dimension==2:
        fig,ax1=plt.subplots(1,1)
        fig2,ax2=plt.subplots(1,1)
        datax,datay=zip(*data)
        ax2.plot(datax,datay,"ro",markersize=2)
        for cluster in clusters:
            cluster_idxs=list(cluster)
            clusterx,clustery=zip(*[(data[idx][0],data[idx][1]) for idx in cluster_idxs])
            ax1.plot(clusterx,clustery,"o",markersize=2)
            ax1.set_xlim(0,1)
            ax1.set_ylim(0,1)
            fig.savefig(f"cluster-results/team-7-{dataset_name}.results.png")
            fig2.savefig(f"cluster-results/team-7-{dataset_name}.train.png")
    
    if dimension==3:
        fig=plt.figure()
        fig2=plt.figure()
        ax=fig.add_subplot(111,projection="3d")
        ax2=fig2.add_subplot(111,projection="3d")
        datax,datay,dataz=zip(*data)
        ax2.scatter(datax, datay, zs=dataz, s=1, alpha=0.1)
        for cluster in clusters:
            cluster_idxs=list(cluster)
            clusterx,clustery,clusterz=zip(*[(data[idx][0],data[idx][1],data[idx][2]) for idx in cluster_idxs])
            ax.scatter(clusterx, clustery, zs=clusterz, s=1, alpha=0.5)
            ax.set_xlim(-0.05,1)
            ax.set_ylim(-0.05,1)
            ax.set_zlim(-0.05,1) # type: ignore
        
        fig.savefig(f"cluster-results/team-7-{dataset_name}.results.png")
        fig2.savefig(f"cluster-results/team-7-{dataset_name}.train.png")

#! ./venv/bin/python3
#%%



def cube_based_tau_clustering(data, h_values, rho, delta, tau, dimension):
    """
    Implement the hint exactly:
    1. Identify which δ-cubes are in Mρ (have points with h >= ρ)
    2. Define cubes as connected if they contain points that are τ-connected
    3. Find connected components of cubes
    4. Each component gives a cluster (union of all points in those cubes)
    """
    # Step 1: Map points to δ-cubes
    cubes_dict = defaultdict(list)  # cube_idx -> list of point indices
    cube_has_point_in_M = defaultdict(bool)  # Track if cube has any point in Mρ
    
    for idx, point in enumerate(data):
        if h_values[idx] >= rho:
            # This point is in Mρ
            cube_idx = tuple(int((point[d] + 1) / (2 * delta)) for d in range(dimension))
            cubes_dict[cube_idx].append(idx)
            cube_has_point_in_M[cube_idx] = True
    
    # Only keep cubes that have points in Mρ
    cubes_in_M = {cube: points for cube, points in cubes_dict.items() 
                  if cube_has_point_in_M[cube]}
    
    if not cubes_in_M:
        return []
    
    # Step 2: Build cube connectivity graph
    # Two cubes are connected if the distance between their closest points ≤ τ
    cube_list = list(cubes_in_M.keys())
    cube_graph = defaultdict(set)
    
    # Precompute min distances between cubes
    for i in range(len(cube_list)):
        cube_i = cube_list[i]
        points_i = cubes_in_M[cube_i]
        
        for j in range(i + 1, len(cube_list)):
            cube_j = cube_list[j]
            points_j = cubes_in_M[cube_j]
            
            # Check if any point in cube_i is τ-connected to any point in cube_j
            connected = False
            for idx_i in points_i:
                point_i = data[idx_i]
                for idx_j in points_j:
                    point_j = data[idx_j]
                    # Compute distance
                    dist_sq = sum((point_i[d] - point_j[d]) ** 2 for d in range(dimension))
                    if dist_sq <= tau ** 2:
                        connected = True
                        break
                if connected:
                    break
            
            if connected:
                cube_graph[cube_i].add(cube_j)
                cube_graph[cube_j].add(cube_i)
    
    # Step 3: Find connected components in cube graph
    visited = set()
    cube_components = []
    
    for cube in cubes_in_M:
        if cube in visited:
            continue
        
        # BFS for this component
        component = set()
        queue = deque([cube])
        visited.add(cube)
        
        while queue:
            current = queue.popleft()
            component.add(current)
            
            for neighbor in cube_graph[current]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        
        cube_components.append(component)
    
    # Step 4: Convert to point clusters
    clusters = []
    for component in cube_components:
        cluster = set()
        for cube in component:
            cluster.update(cubes_in_M[cube])
        clusters.append(cluster)
    
    return clusters

def iteration_over_rho_optimized(data, delta, epsilon_factor, tau_factor):
    """Optimized version using cube-based connectivity."""
    n = len(data)
    d = len(data[0])
    
    # Precompute cubes and h values once
    cubes_dict = precompute_cubes(data, delta, d)
    h_values = compute_h_values(data, delta, cubes_dict)
    
    h_max = max(h_values)
    epsilon = epsilon_factor * (h_max / (n * (2 * delta) ** d))**.5
    tau = tau_factor * delta
    rho_step = 1 / (n * (2 * delta) ** d)
    
    rho_history = []
    B_history = []
    
    rho = 0
    # Get initial clusters
    B_current = cube_based_tau_clustering(data, h_values, rho, delta, tau,d)
    
    while True:
        # Filter clusters based on ρ + 2ε condition
        remaining_clusters = []
        for cluster in B_current:
            # Check if cluster contains points with h >= ρ + 2ε
            max_h_in_cluster = max(h_values[idx] for idx in cluster)
            if max_h_in_cluster >= rho + 2 * epsilon:
                remaining_clusters.append(cluster)
        
        # Stop condition
        if len(remaining_clusters) != 1:
            break
        
        # Store current state
        rho_history.append(rho)
        B_history.append(B_current)
        
        # Increase ρ for next iteration
        rho += rho_step
        
        # Get new clusters for increased ρ
        B_current = cube_based_tau_clustering(data, h_values, rho, delta, tau,d)
    
    return B_current, rho_history, B_history
